# balancer.py untuk xenserver dengan setup resource pool
# pool master adalah 192.168.0.10 (xenserver-zero)

import commands, sys

# # set host's xapi port
# port = 443
# # set username to login
# user = 'root'
# # set password to login
# pasw = 'cloudvm'

def findBestHost(pool_master):
	best_freemem = 0
	best_host = ''
	best_stor = 0
	# get all host in this pool
	gethosts = commands.getoutput('xe host-list --minimal')
	host_uuids = gethosts.split(',')
	for host in host_uuids:
		# get free memory of this host
		freemem = commands.getoutput('xe host-compute-free-memory host=%s' % (host))
		mtotal = commands.getoutput('xe host-param-get -s %s -p %d -pw "%s" -u %s uuid=%s param-name=memory-total host-metrics-live=true' % (host, port, pasw, user, host_uuid))
		freemem_percent = 100*int(freemem)/int(mtotal)
		
	print host_uuids
	# for host in hosts:
	# 	# get uuid
	# 	host_uuid = commands.getoutput('xe -s %s -p %d -pw "%s" -u %s host-list params=uuid --minimal' % (host, port, pasw, user))

	# 	# get free memory
	# 	freemem = commands.getoutput('xe -s %s -p %d -pw "%s" -u %s host-compute-free-memory' % (host, port, pasw, user))
	# 	mtotal = commands.getoutput('xe host-param-get -s %s -p %d -pw "%s" -u %s uuid=%s param-name=memory-total host-metrics-live=true' % (host, port, pasw, user, host_uuid))
	# 	freemem_percent = 100*int(freemem)/int(mtotal)

	# 	# get free storage
	# 	sr_uuid = commands.getoutput('xe -s %s -p %d -pw "%s" -u %s sr-list name-label="%s" --minimal' % (host, port, pasw, user, 'Local storage'))
	# 	virtual_alloc = commands.getoutput('xe -s %s -p %d -pw "%s" -u %s sr-param-get uuid=%s param-name=virtual-allocation' % (host, port, pasw, user, sr_uuid))
	# 	stortotal = commands.getoutput('xe -s %s -p %d -pw "%s" -u %s sr-param-get uuid=%s param-name=physical-size' % (host, port, pasw, user, sr_uuid))
	# 	freestor_percent = 100*int(virtual_alloc)/int(stortotal)

	# 	# if storage used is > 90%, don't consider this host
	# 	if freestor_percent <= 90 and freemem_percent >= best_freemem:
	# 		best_freemem = freemem_percent
	# 		best_host = host
	# 		best_stor = freestor_percent

	# #print 'Best host: %s memory free: %d%% Storage used: %d%%' % (best_host, best_freemem, best_stor)
	# # lazy override sambil benerin backend
	# best_host = 'cloudvm2.ddns.net'
	# return best_host

def findBestHostPort(hosts):
	best_host = findBestHost(hosts)
	if best_host == '192.168.0.10':
		return 2222
	else:
		return 2223

if __name__ == '__main__':
	findBestHost('xenserver-zero')

