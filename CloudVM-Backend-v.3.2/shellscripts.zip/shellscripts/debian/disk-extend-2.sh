#! /bin/sh

### BEGIN INIT INFO
# Provides:          disk-extend
# Required-Start:    $local_fs $network
# Required-Stop:     $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: disk-extend
# Description:       extend LVM
### END INIT INFO

# Carry out specific functions when asked to by the system
case "$1" in
  start)
    echo "Starting disk-extend"
    vgextend debian /dev/xvda3
    lvextend -l +100%FREE /dev/mapper/debian-root
    resize2fs /dev/mapper/debian-root
    update-rc.d -f disk-extend remove
    ;;
  stop)
    echo "Stopping disk-extend"

    # example 1
    # /usr/bin/foobar --config /etc/foo.conf stop

    ;;
  *)
    echo "Usage: /etc/init.d/disk-extend {start|stop}"
    exit 1
    ;;
esac

exit 0