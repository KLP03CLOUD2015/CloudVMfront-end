#!/bin/sh

touch /root/DELETE_ME
cp -fv /root/firsttimesetup.sh /etc/init.d/firsttimesetup
chmod 755 /etc/init.d/firsttimesetup
update-rc.d firsttimesetup defaults