#! /bin/sh

### BEGIN INIT INFO
# Provides:          firsttimesetup
# Required-Start:    $local_fs $network
# Required-Stop:     $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: firsttimesetup
# Description:       trigger disk-extend for first time boot
### END INIT INFO

# Carry out specific functions when asked to by the system
case "$1" in
  start)
    echo "Checking for first time setup"

    if [ -e "/root/DELETE_ME" ]
    then
        rm -fv /root/DELETE_ME
        update-rc.d -f firsttimesetup remove
        /root/disk-extend.sh
    fi
    ;;
  stop)
    echo "Stopping first time setup"

    # example 1
    # /usr/bin/foobar --config /etc/foo.conf stop

    ;;
  *)
    echo "Usage: /etc/init.d/firsttimesetup {start|stop}"
    exit 1
    ;;
esac

exit 0