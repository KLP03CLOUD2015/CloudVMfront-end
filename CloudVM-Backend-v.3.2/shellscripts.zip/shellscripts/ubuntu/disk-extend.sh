#!/bin/sh
echo "u
n
p
3
1046

w" | fdisk /dev/xvda

cp -fv /root/disk-extend-2.sh /etc/init.d/disk-extend
chmod 755 /etc/init.d/disk-extend
update-rc.d disk-extend defaults

reboot